This privacy policy explains how Digi Virtual handles your personal information and data, and applies to all of the products, services and websites offered by Digi Virtual .Digi Virtual products, services and websites are collectively referred to as the “services” in this policy. Unless otherwise noted, all services are provided by Digi Virtual Inc., which is based in the United States.

In this policy, “you” refers to those who use and/or interact with any or all of our products, services, and websites, and “we”, “us”, and “our” refer to Digi Virtual . “Customer”(s) refers specifically to those who use Digi Virtual services. “Form Responders” refers to those who fill in and/or submit forms used by our Customers.

## From Visitors to Our Websites

Usage data. We collect usage data when you interact with our services. This may include which web pages you visit, what you click on, when you performed those actions, and so on. Additionally, like most websites today, our web servers keep log files that record data each time a device accesses those servers. The log files contain data about the nature of each access, including originating IP addresses, internet service providers, the files viewed on our site (e.g., HTML pages, graphics, etc.), operating system versions, and timestamps.
Device data. We collect data from the device and application you use to access our services, such as your IP address, operating system version, device type, system and performance information, and browser type. We may also infer your geographic location based on your IP address.
Referral data. If you arrive at a Digi Virtual website from an external source (such as a link on another website or in an email), we record information about the source that referred you to us.
Information from third parties. We may collect your personal information or data from third parties, if you have given permission to those third parties to share your information.
Information from page tags. We use third party tracking services that employ cookies and page tags (also known as web beacons) to collect aggregated and anonymized data about visitors to our websites. This data includes usage and user statistics. Emails sent by Digi Virtual or by users through our services may include page tags that allow the sender to collect information about who opened those emails and clicked on links in them. We do this to allow the email sender to measure the performance of their email messaging and to learn how to improve email deliverability and open rates.
 

## From Form Responders
When you fill in or complete a form used by one of our Customers, we collect information relating to you and your use of our services:

Form responses. We collect and store the form responses that you submit, in some cases using third party server providers like Amazon Web Services or Google Cloud, on behalf of our Customers. The form creator (Customer) is responsible for this data, and they manage it. A form may ask you to provide personal information or data. If you have any questions about a form which a Customer has sent to you or given you access to fill in, or about the data to be provided in the form, please contact the form creator directly, since Digi Virtual is not responsible for the content of that form. The form creator may have their own privacy policy.
Are your form responses anonymous?
You will need to ask the form creator as it depends on how the individual, company or organization has chosen to configure the form(s). We provide information to form creators on how they can collect responses anonymously. However, even if a form creator has followed those steps, specific questions in the form may still ask you for your personal information or data that could be used to identify you.

## HOW LONG WE RETAIN YOUR INFORMATION
We generally retain your information for as long as you have an account with us, as necessary to otherwise to provide services to you, to comply with our legal obligations, to enforce our agreements and terms of use, and for as long as one or more of your forms remain publicly accessible on our website. If you close your account and make your forms publicly unavailable through your account dashboard, your personal info will be deleted after one month. If your account has not been closed but is inactive for one year, we will hold your personal data in encrypted form for one additional year, at which time we will delete it. We will delete personal info in response to valid data subject requests made under applicable privacy law such as under the GDPR. This paragraph constitutes our data retention policy as to your personal information.

## REQUESTS TO DELETE, AMEND OR WITHDRAW CONSENT – NON-EEA, UK OR AUSTRALIAN RESIDENTS

You may be entitled to request that we delete or amend your personal information. You may also be entitled to withdraw your consent, when consent is the basis for processing your personal information. We apply the same procedures, limitations and exceptions established for European Economic Area (EEA), UK and Australian residents in this privacy policy to all who make such requests to delete or amend personal information, or withdraw consent for processing personal information, regardless of geographic location. Please read the “Your Rights” paragraph under the “ADDITIONAL TERMS FOR EUROPEAN ECONOMIC AREA, UK AND AUSTRALIA RESIDENTS” below for details.

Legal Basis for Use of Your Information
Personal information that we collect is processed under the following legal basis:

Our legitimate interests. This includes:

to enable us to provide our products and services and website use and access to you
for analytics, to gather metrics to better understand how users use the our websites, and to evaluate and improve our websites
to prevent fraud and other illegal activity
the legitimate interests of others (for example, to ensure the security of our website)
to comply with legal obligations, as part of our general business operations, and for other internal business administration purposes
if we collect demographic information from you (such as gender and ethnic origin) in order to carry out diversity monitoring and such information is not collected in an anonymous format, then we rely on our legitimate interest to do so.
## Your Rights
### Deletion of Personal Information
You may be entitled to request that we delete your personal information in certain specific circumstances. If you wish to exercise this right, please submit your request using this form. We will consider all such requests and provide our response within a reasonable period (but no longer than one calendar month from our receipt of your request unless we tell you that we are entitled to a longer period under applicable law). We may require you to verify your identity before we respond to your request. Certain personal information may be exempt from such requests in certain circumstances, including as provided for in this privacy policy.

### Access, Update, Data Portability and Other Rights
You may also be entitled to access your information, update your personal information which is out of date or incorrect, restrict use of your personal information in certain specific circumstances, place a data portability request (applicable only when we use your personal information on the basis of your consent or performance of a contract, and where our use of your information is carried out by automated means), and ask us to consider any valid objections which you have to our use of your personal information where we process it on the basis of our or another person’s legitimate interest. Requests should be directed via this form.

We will consider all such requests and provide our response within a reasonable period (but no longer than one calendar month from our receipt of your request unless we tell you we are entitled to a longer period under applicable law). We may require you to verify your identity before we respond to any of your requests. Certain personal information may be exempt from such requests in certain circumstances, including as provided for in this privacy policy.

## Children’s Privacy
Use of our websites is intended for adults at least eighteen (18) years of age. We do not knowingly collect personally-identifying information from children under the age of thirteen (13).