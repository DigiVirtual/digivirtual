# Categories

You can use categories to find products easily.

Following is a list of relevant categories:

[TAGS]